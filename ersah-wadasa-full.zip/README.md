# إرث وعدسة - نسخة تجريبية

شغل `docker-compose up --build` بعد تعديل المتغيرات في `.env.example`.
