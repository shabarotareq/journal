import React from 'react'
import { createRoot } from 'react-dom/client'
function App(){ return <div><h1>إرث وعدسة — واجهة تجريبية</h1></div> }
createRoot(document.getElementById('root')).render(<App />)