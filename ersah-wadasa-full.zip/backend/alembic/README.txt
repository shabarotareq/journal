Alembic folder placeholder. For real migrations:
1) pip install alembic
2) alembic init alembic
3) edit alembic.ini and env.py to point to your SQLALCHEMY DB URL and models metadata